import { Injectable, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from './roles';

type JwtPayload = { sub: number };

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(
    configService: ConfigService,
    private readonly prisma: PrismaService,
  ) {
    const secret = configService.get<string>('JWT_SECRET')?.trim();
    if (!secret) {
      throw new Error('JWT_SECRET no esta definido. Configuralo en apps/api/.env antes de iniciar la API.');
    }

    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      secretOrKey: secret,
      ignoreExpiration: false,
    });
  }

  // Passport llama a validate() con el payload ya verificado (firma + expiracion ok).
  // Hacemos el mismo lookup completo que antes hacia el AuthGuard custom, para no
  // perder el chequeo de "activo" ni el armado de rol/permisos.
  async validate(payload: JwtPayload): Promise<AuthUser> {
    const usuario = await this.prisma.usuario.findUnique({
      where: { id: payload.sub },
      include: {
        rol: {
          include: {
            permisos: { include: { permiso: true } },
          },
        },
      },
    });

    if (!usuario || !usuario.activo) throw new UnauthorizedException('Debe iniciar sesion');

    return {
      sub: usuario.id,
      email: usuario.email,
      nombre: usuario.nombre,
      rol: usuario.rol.codigo as AuthUser['rol'],
      permisos: usuario.rol.permisos.map((rolPermiso) => rolPermiso.permiso.codigo) as AuthUser['permisos'],
    };
  }
}
